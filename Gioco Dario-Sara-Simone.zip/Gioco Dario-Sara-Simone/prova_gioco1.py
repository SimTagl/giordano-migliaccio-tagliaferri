from random import randint
import pgzrun
import pygame
import time
import os


WIDTH = 800
HEIGHT = 600

game_over = False


ostacolo1 = Actor("auto_verde")

ostacolo2 = Actor("auto_azzurra")

ostacolo3 = Actor("auto_rosa")

ostacolo4 = Actor("auto_gialla")

ostacolo5 = Actor("crepa")
ostacolo5.pos = 440, 130

barriera = Actor("aiuola")
barriera.pos = 300, 250

barriera2 = Actor("aiuola2")
barriera2.pos = 500, 250

coin = Actor("moneta")
coin.pos = 400, 180

auto = Actor("auto")
auto.pos = 400, 300

def update():

    global score


    if keyboard.left:
        auto.x = auto.x - 3
    elif keyboard.right:
        auto.x = auto.x + 3
    elif keyboard.up:
        auto.y = auto.y - 7
    elif keyboard.down:
        auto.y = auto.y + 5



    
def draw():
        screen.fill((169,169,169))
        if not game_over:
            auto.draw()
            coin.draw()
            barriera.draw()
            barriera2.draw()
            ostacolo5.draw()


            

pgzrun.go()
