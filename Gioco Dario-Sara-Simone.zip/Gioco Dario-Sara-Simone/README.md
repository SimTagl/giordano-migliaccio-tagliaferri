# giordano-migliaccio-tagliaferri
L'obiettivo del gioco è quello di realizzare una macchina che sarà il personaggio principale con la funzione di evitare le altre 
macchine presenti sulla strada (ostacoli). Quando si avvia il gioco appare lo sfondo con 3 sezioni:Gioca, Record e Auto. 
Quando si clicca Gioca apparirà il nuovo sfondo con la strada, il pulsante pausa e due tasti per sterzare a destra e sinistra
 e il main actor (la nostra macchina) che avrà la velocità iniziale di 20 e aumenta di 2 se non si clicca niente invece 
diminuisce di 3 ogni volta che l'utente tocca il tasto di frenata. Il punteggio iniziale è 0 e aumenta di 100 se non colpisce 
le macchine, però se la velocità è sopra la soglia di 100 il punteggio aumenta di 200. Se la macchina colpisce un'altra macchina, sullo schermo apparirà GAME OVER! con il punteggio ottenuto, il tasto Rigioca e il tasto Torna al menù. 
Quando si apre la sezione Record verranno mostrati tutti i punteggi ottenuti in ogni gara elencate in ordine decrescente in base 
al punteggio e in questa sezione verrano salvati tutti i dati ricavabili dal gioco. 
Nella sezione Auto saranno presenti tutte le auto sbloccabili nel gioco, dove con 1000 punti si sbloccherà la prima auto 
collezionabile e per ottenere altre nuove auto bisogerà raddoppiare il precedente numero di punti necessari per sbloccare 
la scorsa auto.
