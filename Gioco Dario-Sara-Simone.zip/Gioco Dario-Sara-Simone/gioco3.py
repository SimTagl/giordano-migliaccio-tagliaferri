import random
from random import randint
import pgzrun
import pygame
import tkinter as tk
import time
import os



#area di  gioco
WIDTH = 800
HEIGHT = 600


#variabili
score = 0
turbo = 0
speed = 5
speed2 = 3
nCoin = 0

game_over = False



#Zona Actor
auto = Actor("auto")
auto.pos = 400, 500

ostacolo5 = Actor("crepa")
ostacolo5.pos = randint(220, 490), randint(5, 280)
ostacolo5a = Actor("crepa")
ostacolo5a.pos = randint(220, 490), randint(5, 280)
upgrade = Actor("tanica")
upgrade.pos = randint(180, 490), randint(-800, -600)
upgrade2 = Actor("tanica")
upgrade2.pos = randint(180, 490), randint(-800, -600)

#liste
ostacoli=["auto_verde", "auto_azzurra", "auto_rosa", "auto_gialla"]
autolist=[]
coin = []



#Varie funzioni

def newCoin():
    global coin
    nuovo_coin = Actor("moneta")
    nuovo_coin.pos = randint(180, 490), randint(5, 250)

def initCoin():
   
    for i in  range(6):
        print(i)
        newCoin()
       

def newAuto():
    global ostacoli
    nuova_auto = Actor(ostacoli.choise())
    nuova_auto.pos = (randint(180, 490), randint(-100, 0))
    auto.append(nuova_auto)
   

def schianto():
    global game_over
    game_over = True
    screen.fill("black")
    screen.draw.text("Coin: " + str(score), color="yellow", topleft=(10,10), fontsize = 100)

def fossa_presa():
    global speed
    global speed2

'''  
def place_coin():
    coin.x = randint(100, 490)
    coin.y = randint(0, 0)
'''

def place_tanica():
    upgrade.x = randint(100, 590)
    upgrade.y = randint(-800, -600)

def place_tanica2():
    upgrade2.x = randint(100, 590)
    upgrade2.y = randint(-800, -600)


#Disegni
def draw():

    screen.fill((169,169,169))
    auto.draw()
    for nuovo_coin in coin:
        nuovo_coin.draw()

    for nAutolist in autolist:
        nAutolist.draw()
    
    upgrade.draw()

    screen.draw.text("Coin: " + str(score), color="yellow", topleft=(10,10), fontsize = 40)
    screen.draw.text("Turbo: " + str(turbo), color="green", topleft=(10,40), fontsize = 40)




#Funzionamento degli Actor
def update():

    global score
    global turbo
    global speed
    global speed2
    global nCoin

    print(nCoin)
    if (nCoin<=6):

        for i in range(6-nCoin):
            print("genera ",i," coin")
            newCoin()
            nCoin=nCoin+1
            

    if keyboard.left:
        auto.x = auto.x - (speed2)
    elif keyboard.right:
        auto.x = auto.x + (speed2)
    elif keyboard.up:
        auto.y = auto.y - (speed)
    elif keyboard.down:
        auto.y = auto.y + (speed)
    elif keyboard.T:
        if turbo >= 10:
            speed = speed + 1
            turbo = turbo - 10
   
    for i in coin:
        if i.y>HEIGHT:
            i.pos = randint(100, 590), randint(0, 0)

    upgrade.y += 2
    if upgrade.y>HEIGHT:
            upgrade.pos = randint(100, 490), randint(-800, -600)

    upgrade2.y += 2
    if upgrade2.y>HEIGHT:
            upgrade2.pos = randint(100, 490), randint(0, 0)

    tanica_collected = auto.colliderect(upgrade)
    if tanica_collected:
        turbo = turbo + 10
        place_tanica()

    incidente = auto.colliderect(ostacolo5)
    if incidente:
        schianto()
   

pgzrun.go()
