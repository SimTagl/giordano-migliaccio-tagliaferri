import random
from random import randint
import pgzrun
import pygame
import tkinter as tk
import time
import os



#area di  gioco
WIDTH = 800
HEIGHT = 600


#variabili
score = 0
turbo = 0
speed = 5
speed2 = 3

game_over = False



#Zona Actor
auto = Actor("auto")
auto.pos = 400, 500
ostacolo1 = Actor("auto_verde")
ostacolo1.pos = 500, 0
ostacolo2 = Actor("auto_azzurra")
ostacolo2.pos = 600, 0
ostacolo3 = Actor("auto_rosa")
ostacolo4 = Actor("auto_gialla")
ostacolo5 = Actor("crepa")
ostacolo5.pos = randint(220, 490), randint(5, 280)
ostacolo5a = Actor("crepa")
ostacolo5a.pos = randint(220, 490), randint(5, 280)
coin = Actor("moneta")
coin.pos = randint(180, 490), randint(5, 250)
coin2 = Actor("moneta")
coin2.pos = randint(180, 490), randint(5, 250)
coin3 = Actor("moneta")
coin3.pos = randint(180, 490), randint(5, 250)
coin4 = Actor("moneta")
coin4.pos = randint(180, 490), randint(5, 250)
coin5 = Actor("moneta")
coin5.pos = randint(180, 490), randint(5, 250)
coin6 = Actor("moneta")
coin6.pos = randint(180, 490), randint(5, 250)
upgrade = Actor("tanica")
upgrade.pos = randint(180, 490), randint(-800, -600)
upgrade2 = Actor("tanica")
upgrade2.pos = randint(180, 490), randint(-800, -600)



#Varie funzioni
def schianto():
    global game_over
    game_over = True
    screen.fill("black")
    screen.draw.text("Coin: " + str(score), color="yellow", topleft=(10,10), fontsize = 100)

def fossa_presa():
    global speed
    global speed2
    
def place_coin():
    coin.x = randint(100, 490)
    coin.y = randint(0, 0)

def place_coin2():
    coin2.x = randint(100, 490)
    coin2.y = randint(0, 0)

def place_coin3():
    coin3.x = randint(100, 490)
    coin3.y = randint(0, 0)

def place_coin4():
    coin4.x = randint(100, 490)
    coin4.y = randint(0, 0)

def place_coin5():
    coin5.x = randint(100, 490)
    coin5.y = randint(0, 0)

def place_coin6():
    coin6.x = randint(100, 490)
    coin6.y = randint(0, 0)

def place_tanica():
    upgrade.x = randint(100, 590)
    upgrade.y = randint(-800, -600)

def place_tanica2():
    upgrade2.x = randint(100, 590)
    upgrade2.y = randint(-800, -600)


#Disegni
def draw():
        screen.fill((169,169,169))
        if not game_over:
            auto.draw()
            coin.draw()
            coin2.draw()
            coin3.draw()
            coin4.draw()
            coin5.draw()
            coin6.draw()
            ostacolo1.draw()
            ostacolo2.draw()
            ostacolo3.draw()
            ostacolo4.draw()
            ostacolo5.draw()
            ostacolo5a.draw()
            upgrade.draw()
            screen.draw.text("Coin: " + str(score), color="yellow", topleft=(10,10), fontsize = 40)
            screen.draw.text("Turbo: " + str(turbo), color="green", topleft=(10,40), fontsize = 40)




#Funzionamento degli Actor
def update():

    global score
    global turbo
    global speed
    global speed2


    if keyboard.left:
        auto.x = auto.x - (speed2)
    elif keyboard.right:
        auto.x = auto.x + (speed2)
    elif keyboard.up:
        auto.y = auto.y - (speed)
    elif keyboard.down:
        auto.y = auto.y + (speed)
    elif keyboard.T:
        if turbo >= 10:
            speed = speed + 1
            turbo = turbo - 10
    

    coin.y += 2
    if coin.y>HEIGHT:
            coin.pos = randint(100, 590), randint(0, 0)

    coin2.y += 2
    if coin2.y>HEIGHT:
            coin2.pos = randint(100, 590), randint(0, 0)

    coin3.y += 2
    if coin3.y>HEIGHT:
            coin3.pos = randint(100, 590), randint(0, 0)

    coin4.y += 2
    if coin4.y>HEIGHT:
            coin4.pos = randint(100, 590), randint(0, 0)

    coin5.y += 2
    if coin5.y>HEIGHT:
            coin5.pos = randint(100, 590), randint(0, 0)

    coin6.y += 2
    if coin6.y>HEIGHT:
            coin6.pos = randint(100, 590), randint(-800, -600)

    upgrade.y += 2
    if upgrade.y>HEIGHT:
            upgrade.pos = randint(100, 490), randint(-800, -600)

    upgrade2.y += 2
    if upgrade2.y>HEIGHT:
            upgrade2.pos = randint(100, 490), randint(0, 0)
            
    ostacolo1.y += 2
    if ostacolo1.y>HEIGHT+100:
            ostacolo1.pos = randint(100, 490), randint(-150, -100)

    ostacolo2.y -= 2
    if ostacolo2.y<HEIGHT-700:
            ostacolo2.pos = randint(100, 490), randint(650, 700)

    ostacolo3.y -= 2
    if ostacolo3.y<HEIGHT-700:
            ostacolo3.pos = randint(100, 490), randint(650, 700)

    ostacolo4.y += 2
    if ostacolo4.y>HEIGHT+100:
            ostacolo4.pos = randint(100, 490), randint(-150, -100)
            
    ostacolo5.y += 2
    if ostacolo5.y>HEIGHT:
            ostacolo5.pos = randint(200, 490), randint(-100, -50)

    ostacolo5a.y += 2
    if ostacolo5a.y>HEIGHT:
            ostacolo5a.pos = randint(200, 490), randint(-100, -50)

    coin_collected = auto.colliderect(coin)
    if coin_collected:
        score = score + 1
        place_coin()

    coin_collected2 = auto.colliderect(coin2)
    if coin_collected2:
        score = score +1
        place_coin2()  

    coin_collected3 = auto.colliderect(coin3)
    if coin_collected3:
        score =  score + 1
        place_coin3()

    coin_collected4 = auto.colliderect(coin4)
    if coin_collected4:
        score = score + 1
        place_coin4()

    coin_collected5 = auto.colliderect(coin5)
    if coin_collected5:
        score = score + 1
        place_coin5()

    coin_collected6 = auto.colliderect(coin6)
    if coin_collected6:
        score = score + 1
        place_coin6()

    tanica_collected = auto.colliderect(upgrade)
    if tanica_collected:
        turbo = turbo + 10
        place_tanica()

    incidente = auto.colliderect(ostacolo1)
    if incidente:
        schianto()
        
    incidente2 = auto.colliderect(ostacolo2)
    if incidente2:
        schianto()

    incidente3 = auto.colliderect(ostacolo3)
    if incidente3:
        schianto()

    incidente4 = auto.colliderect(ostacolo4)
    if incidente4:
        schianto()
pgzrun.go()
